package eu.gotime;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
